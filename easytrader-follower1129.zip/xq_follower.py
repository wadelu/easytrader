# -*- coding: utf-8 -*-
from __future__ import division, print_function, unicode_literals

import json
from logging import exception
import re
import time
from datetime import datetime
from numbers import Number
from threading import Thread

from easytrader.follower import BaseFollower
from easytrader.log import logger
from easytrader.utils.misc import parse_cookies_str


class XueQiuFollower(BaseFollower):
    LOGIN_PAGE = "https://www.xueqiu.com"
    LOGIN_API = "https://xueqiu.com/snowman/login"
    TRANSACTION_API = "https://xueqiu.com/cubes/rebalancing/history.json"
    PORTFOLIO_URL = "https://xueqiu.com/p/"
    WEB_REFERER = "https://www.xueqiu.com"

    def __init__(self):
        super().__init__()
        self._adjust_sell = None
        self._users = None

    def login(self, user=None, password=None, **kwargs):
        """
        雪球登陆， 需要设置 cookies
        :param cookies: 雪球登陆需要设置 cookies， 具体见
            https://smalltool.github.io/2016/08/02/cookie/
        :return:
        """
        cookies = kwargs.get("cookies")
        if cookies is None:
            raise TypeError(
                "雪球登陆需要设置 cookies， 具体见" "https://smalltool.github.io/2016/08/02/cookie/"
            )
        headers = self._generate_headers()
        self.s.headers.update(headers)
        self.s.get(self.LOGIN_PAGE)
        cookie_dict = parse_cookies_str(cookies)
        self.s.cookies.update(cookie_dict)
        logger.info("雪球客户端登录成功！")

    def follow(  # type: ignore
        self,
        users,
        strategies,
        total_assets=10000,
        initial_assets=None,
        adjust_sell=False,
        track_interval=3,
        trade_cmd_expire_seconds=120,
        cmd_cache=True,
        slippage: float = 0.0,
    ):
        """跟踪 joinquant 对应的模拟交易，支持多用户多策略
        :param users: 支持 easytrader 的用户对象，支持使用 [] 指定多个用户
        :param strategies: 雪球组合名, 类似 ZH123450
        :param total_assets: 雪球组合对应的总资产， 格式 [组合1对应资金, 组合2对应资金]
            若 strategies=['ZH000001', 'ZH000002'],
                设置 total_assets=[10000, 10000], 则表明每个组合对应的资产为 1w 元
            假设组合 ZH000001 加仓 价格为 p 股票 A 10%,
                则对应的交易指令为 买入 股票 A 价格 P 股数 1w * 10% / p 并按 100 取整
        :param adjust_sell: 是否根据用户的实际持仓数调整卖出股票数量，
            当卖出股票数大于实际持仓数时，调整为实际持仓数。目前仅在银河客户端测试通过。
            当 users 为多个时，根据第一个 user 的持仓数决定
        :type adjust_sell: bool
        :param initial_assets: 雪球组合对应的初始资产,
            格式 [ 组合1对应资金, 组合2对应资金 ]
            总资产由 初始资产 × 组合净值 算得， total_assets 会覆盖此参数
        :param track_interval: 轮训模拟交易时间，单位为秒
        :param trade_cmd_expire_seconds: 交易指令过期时间, 单位为秒
        :param cmd_cache: 是否读取存储历史执行过的指令，防止重启时重复执行已经交易过的指令
        :param slippage: 滑点，0.0 表示无滑点, 0.05 表示滑点为 5%
        """
        super().follow(
            users=users,
            strategies=strategies,
            track_interval=track_interval,
            trade_cmd_expire_seconds=trade_cmd_expire_seconds,
            cmd_cache=cmd_cache,
            slippage=slippage,
        )
        nowDate = datetime.now()
        dayWeek = nowDate.weekday()
        while dayWeek not in [0,1,2,3,4]:
            time.sleep(3600)
        time1 = datetime.strptime(str(nowDate.date())+'9:30', '%Y-%m-%d%H:%M')
        time2 = datetime.strptime(str(nowDate.date())+'11:30', '%Y-%m-%d%H:%M')
        time3 = datetime.strptime(str(nowDate.date())+'13:00', '%Y-%m-%d%H:%M')
        time4 = datetime.strptime(str(nowDate.date())+'23:00', '%Y-%m-%d%H:%M')
        while not ((nowDate > time1 and nowDate < time2) or (nowDate > time3 and nowDate < time4)) :
            logger.info('非交易时间，程序休眠中……')
            time.sleep(10)
        #初始化交易数据
        self._adjust_sell = adjust_sell
        self._users = self.warp_list(users)
        strategies = self.warp_list(strategies)
        total_assets = self.warp_list(total_assets)
        initial_assets = self.warp_list(initial_assets)
        logger.debug('策略：资产：初始资产组合：%s',list(zip(strategies,total_assets)));
        # exit()
        if cmd_cache: #加载已执行指令
            self.load_expired_cmd_cache()
        #开启交易线程
        self.start_trader_thread(self._users, trade_cmd_expire_seconds)
        
        #遍历策略，获取每个策略交易数据
        for strategy_url, strategy_total_assets in zip(
            strategies, total_assets
        ):
            #获取测录元数据
            assets = self.calculate_assets(strategy_url, strategy_total_assets)
            try:
                strategy_id = self.extract_strategy_id(strategy_url)
                strategy_name = self.extract_strategy_name(strategy_url)
            except:
                logger.error("抽取交易id和策略名失败, 无效模拟交易url: %s", strategy_url)
                raise
            #开启策略跟踪线程
            strategy_worker = Thread(
                target=self.track_strategy_worker,
                args=[strategy_id, strategy_name],
                kwargs={"interval": track_interval, "assets": assets, "expire_seconds": trade_cmd_expire_seconds},
            )
            time.sleep(6) #每个查询策列间隔5s开启
            strategy_worker.start()
             #招商证券自定义账户信息，其他券商需要修改或者取消该日志输出
            # logger.info("%s账户:%s登陆成功，跟踪资产：%s", self._users[0].balance['broker'],self._users[0].balance['account'],strategy_total_assets)
            logger.info("%s账户:%s，开始跟踪策略: %s[%s]，策略资产：%s", self._users[0].balance['broker'],self._users[0].balance['account'],strategy_name,strategy_id,assets)

    def calculate_assets(self, strategy_url, total_assets=None, initial_assets=None):
        """
        计算总资产
        """
        # 都设置时优先选择 total_assets
        if total_assets is None and initial_assets is not None:
            net_value = self._get_portfolio_net_value(strategy_url)
            total_assets = initial_assets * net_value
        if not isinstance(total_assets, Number):
            raise TypeError("总资产无效，total_assets必须是数字类型")
        if total_assets < 1e3:
            raise ValueError("总资产不能小于1000元，当前预设值 {}".format(total_assets))
        return total_assets

    @staticmethod
    def extract_strategy_id(strategy_url):
        return strategy_url

    def extract_strategy_name(self, strategy_url):
        """
        获取策略名
        """
        base_url = "https://xueqiu.com/cubes/nav_daily/all.json?cube_symbol={}"
        url = base_url.format(strategy_url)
        rep = self.s.get(url)
        info_index = 0
        return rep.json()[info_index]["name"]

    def extract_transactions(self, history, expire_seconds, assets=10000):
        """
        解析策略记录
        """
        transactions = []
        try:
            if history["count"] <= 0:
                return transactions
        except:
            logger.info("解析调仓记录错误: %s", json.dumps(history, ensure_ascii=False))
            time.sleep(11)#查询策略失败，等待10s再试
            return transactions
        # exit()         
        for trans in history['list']:
              # 调仓状态
            if trans["status"] == 'success': #["pending", "canceled", "failed"]:
                for transaction in trans["rebalancing_histories"]:
                    # logger.debug("交易时间：%s， 交易ID：%s", (datetime.fromtimestamp(transaction['updated_at']/1000).strftime('%Y-%m-%d %H:%M:%S')), transaction['id'])
                    if transaction["price"] is None:
                        logger.debug("该笔交易无法获取价格，跳过。交易详情: %s", transaction)
                        continue
                    # logger.debug('当前时间戳：%s，交易时间：%s，过期时间：%s',int(datetime.now().timestamp()*1000), transaction['updated_at'], expire_seconds*1000)
                    if int(datetime.now().timestamp()*1000) - transaction['updated_at'] > expire_seconds*1000:
                        logger.debug("该笔交易已过期，跳过。交易详情: %s", transaction)
                        continue
                    transactions.append(transaction)
            else:
                logger.debug("忽略无效委托: %s", json.dumps(trans))
                continue
        return transactions

    def create_query_transaction_params(self, strategy):
        """
        构建策略查询参数
        """
        params = {"cube_symbol": strategy, "page": 1, "count": 20}
        return params

    # noinspection PyMethodOverriding
    def none_to_zero(self, data):
        """
        将None转换成0
        """
        if data is None:
            return 0
        return data

    # noinspection PyMethodOverriding
    def project_transactions(self, transactions, assets, expire_seconds=3600):
        """
        校正策略交易数据
        """
        for transaction in transactions:
            logger.debug("调仓记录：%s",transaction)
            weight_diff = self.none_to_zero(transaction["weight"]) - self.none_to_zero(
                transaction["prev_weight"]
            )
            initial_amount = abs(weight_diff)/100 * assets / transaction["price"]
            logger.debug("计算交易量：%s",initial_amount)
            transaction["datetime"] = datetime.fromtimestamp(
                transaction["created_at"] // 1000
            )
            transaction["stock_code"] = transaction["stock_symbol"].lower()
            transaction["action"] = "buy" if weight_diff > 0 else "sell"
            initial_amount = int(round(initial_amount, -2))
            transaction["amount"] = initial_amount if initial_amount > 100 else 100
            #根据账户资金持仓调整交易数量
            transaction["amount"] = self._adjust_amount(transaction["stock_code"], transaction["amount"], transaction["price"], transaction["action"])
            logger.debug("最终交易量：%s", transaction["amount"])    
            logger.debug("资产%s, 交易数据：%s",assets,transaction)

    def _adjust_amount(self, stock_code, amount, price, action='buy'):
        """
        根据实际可以用资金和持仓计算股数。因为雪球的交易指令是基于持仓百分比，
        在取近似值的情况下可能出现不精确的问题。导致如下情况的产生，
        计算出的指令为买入 1049 股，取近似值买入 1000 股。而卖出的指令计算出为卖出 1051 股，
        取近似值卖出 1100 股，超过 1000 股的买入量，导致交易失败。
        :param stock_code: 证券代码
        :param amount: 交易数
        :param action: 交易方式:buy/sell 
        :return: 根据实际持仓和可用资金计算过后的股数
        :rtype: int
        """
        stock_code = stock_code[-6:]
        user_balance = self._users[0].get_balance()
        position = user_balance['holding']
        if action == 'sell':
            try:
                stock = next(h for h in position if h['zqdm'] == stock_code)
                #logger.info('可用余额%s',stock["kyye"])
                if int(stock["kyye"]) >= amount:
                    return amount
                else:
                    logger.debug("证券%s卖出指令，数量为%s，调整为实际可用数量%s，价格为%s",stock_code,amount,stock["kyye"],price)
                    return stock["kyye"]
            except StopIteration:
                logger.debug("收到%s已价格%s卖出指令，但实际未持有，调整售出量为0",stock_code,price)
                return 0
        elif action == 'buy':
            if float(amount*price) > user_balance['enable_balance']*0.95:
                #根据可用资金调整交易数量为100的整数倍
                adjust_amount = user_balance['enable_balance']*0.95 / price //100*100 
                logger.debug("收到%s买入指令，数量为%s，需要%s元，可用资金为%s，调整交易量为%s",
                    stock_code,amount,amount*price,user_balance['enable_balance']*0.95,adjust_amount)
                return adjust_amount
            else: 
                return amount
        else:
            return amount

    def _adjust_sell_amount(self, stock_code, amount):
        """
        根据实际持仓值计算雪球卖出股数
          因为雪球的交易指令是基于持仓百分比，在取近似值的情况下可能出现不精确的问题。
        导致如下情况的产生，计算出的指令为买入 1049 股，取近似值买入 1000 股。
        而卖出的指令计算出为卖出 1051 股，取近似值卖出 1100 股，超过 1000 股的买入量，
        导致卖出失败
        :param stock_code: 证券代码
        :type stock_code: str
        :param amount: 卖出股份数
        :type amount: int
        :return: 考虑实际持仓之后的卖出股份数
        :rtype: int
        """
        stock_code = stock_code[-6:]
        user = self._users[0]
        position = user.position
        try:
            stock = next(s for s in position if s["证券代码"] == stock_code)
        except StopIteration:
            logger.info("根据持仓调整 %s 卖出额，发现未持有股票 %s, 不做任何调整", stock_code, stock_code)
            return amount

        available_amount = stock["可用余额"]
        if available_amount >= amount:
            return amount

        adjust_amount = available_amount // 100 * 100
        logger.info(
            "股票 %s 实际可用余额 %s, 指令卖出股数为 %s, 调整为 %s",
            stock_code,
            available_amount,
            amount,
            adjust_amount,
        )
        return adjust_amount

    def _get_portfolio_info(self, portfolio_code):
        """
        获取组合信息
        """
        url = self.PORTFOLIO_URL + portfolio_code
        portfolio_page = self.s.get(url)
        match_info = re.search(r"(?<=SNB.cubeInfo = ).*(?=;\n)", portfolio_page.text)
        if match_info is None:
            raise Exception("cant get portfolio info, portfolio url : {}".format(url))
        try:
            portfolio_info = json.loads(match_info.group())
        except Exception as e:
            raise Exception("get portfolio info error: {}".format(e))
        return portfolio_info

    def _get_portfolio_net_value(self, portfolio_code):
        """
        获取组合净值
        """
        portfolio_info = self._get_portfolio_info(portfolio_code)
        return portfolio_info["net_value"]
