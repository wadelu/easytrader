# -*- coding: utf-8 -*-
__author__ = "lw@5niu.top"

import json
import numbers
import os
import re
import time
import random
import pandas as pd

import requests

from easytrader import exceptions, webtrader
from easytrader.log import logger
from easytrader.utils.misc import parse_cookies_str


class NewoneTrader(webtrader.WebTrader):
    config_path = os.path.dirname(__file__) + "/config/newone.json"
    _HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36 Edg/96.0.1054.29",
        "Host": "xtrade.newone.com.cn",
        # "Pragma": "no-cache",
        "Connection": "keep-alive",
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Cache-Control": "no-cache",
        "Referer": "https://xtrade.newone.com.cn/npctrade",
        # "X-Requested-With": "XMLHttpRequest",
        # "Content-Length": "189",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://xtrade.newone.com.cn",
        "sec-ch-ua-platform": "Windows",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "sec-ch-ua": "' Not A;Brand';v='99', 'Chromium';v='96', 'Microsoft Edge';v='96'",
        "sec-ch-ua-mobile": '?0'
    }

    @staticmethod
    def _time_strftime(time_stamp):
        try:
            local_time = time.localtime(time_stamp / 1000)
            return time.strftime("%Y-%m-%d %H:%M:%S", local_time)
        # pylint: disable=broad-except
        except Exception:
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


    def __init__(self, **kwargs):
        super(NewoneTrader, self).__init__()
        self.s = requests.Session()
        self.s.verify = False
        self.s.headers.update(self._HEADERS)
        self.account_config = None

    def autologin(self, **kwargs):
        """
        使用 cookies 之后不需要自动登陆
        :return:
        """
        self._set_cookies(self.account_config["cookies"])

    def _set_cookies(self, cookies):
        """设置cookies
        :param cookies: cookies
        :type cookies: str
        """
        logger.debug("设置cookies：%s", cookies)
        cookies_dict = parse_cookies_str(cookies)
        # cookies_dict = requests.utils.dict_from_cookiejar(json.loads(cookies))
        # cookies_str = json.dumps(cookies_dict)
        # f = open('cookies.txt', 'w')
        # f.write(cookies_str)
        # f.close()

        # cookies_txt = open('cookies.txt', 'r')
        # cookies_dict = json.loads(cookies)
        # cookies = requests.utils.cookiejar_from_dict(cookies)
        # return (cookies)

        self.s.cookies.update(cookies_dict)

    def _prepare_account(self, user="", password="", **kwargs):
        """
        转换参数到登录所需的字典格式
        :param cookies: cookies
        :return:
        """
        if "cookies" not in kwargs:
            raise TypeError(
                "登陆需要设置cookies"
            )
        self.account_config = {
            "cookies": kwargs["cookies"],
        }

    def _get_html(self, url):
        return self.s.get(url).text

    def _post(self, url, data={}):
        res = self.s.post(url, data=data, timeout=8).text
        cookies_dict = requests.utils.dict_from_cookiejar(self.s.cookies)
        self.s.cookies.update(cookies_dict)
        logger.debug('Post提交数据:%s',(data))
        logger.debug('Post返回数据:%s', res)
        logger.debug('Post返回Cookies:%s',(cookies_dict))
        cookies_str = str(cookies_dict)[1:-1].replace("'","").replace(": ","=").replace(", ",";")
        logger.debug('Cookies转换为str:%s',cookies_str)
        #更新cookies到文件
        cookies_file = os.path.dirname(__file__)+'/config/newone.cookies'
        if os.path.isfile(cookies_file):
            try:
                with open(cookies_file, "w") as f:
                    f.write(cookies_str)
                    f.close()
            except Exception:
                logger.warn("更新cookies失败，请注意检查交易客户端是否过期")
        return res

    def _search_stock_info(self, code):
        """
        :code: 股票代码
        :return: 行情
        {"scdm":"1","zqjc":"长春经开","zqdm":"600215","xj":"10.07","zt":"12.25","dt":"10.03","zrsp":"11.14","bjw1":"10.07","bjw2":"10.06","bjw3":"10.05","bjw4":"10.04","bjw5":"10.03","bsl1":"551","bsl2":"257","bsl3":"242","bsl4":"318","bsl5":"1133","sjw1":"10.08","sjw2":"10.09","sjw3":"10.10","sjw4":"10.12","sjw5":"10.13","ssl1":"20","ssl2":"7","ssl3":"80","ssl4":"3","ssl5":"152","zd":"-0.0961","zdbl":"1528.0000"}
        """
        data = {
            "zqdm": code,
            "mmlx": "1",
        }

        try:
            res = self._post(self.config["search_stock_url"], data=data)
            stock = json.loads(res)['content']['hq']
            logger.debug("查询股票价格成功：%s", stock)
            return stock
        except Exception as e:
            logger.warn("获取股票信息失败: {}".format(e))
            return False

    def _get_balance_info(self):
        """
        获取资金股份信息
        :return: {'asset_balance': '9310.18', 'profit': '-1056.02', 'enable_balance': '84.98', 'market_value': '9225.20', 'money_type': '人民币', 'pre_interest': 0.1, 
        'holding': [{'xj': '142.020', 'iscyb': '0', 'ksgsl': '1', 'zqmc': 'N宏发转', 'zrqshsz': '1000.00', 'zcxzsl': '0.00', 'fdyk': '420.20', 'hl': '', 'kyye': '1', 'mmjec': '0.00', 'scdm': '1', 'gddm': 'A794459451', 'zrhgsz': '0.00', 'zqdm': '110082', 'kztsl': '1', 'sddjsl': '0.00', 'sz': '1420.20', 'zqsldw': '手', 'drmrsl': '0', 'dzptjced': '1.00', 'bfrq': '20211123', 'etfshdjsl': '0', 'jgbz': '01', 'jzcjsl': '0.00', 'drmcsl': '0', 't1hgsz': '0.00', 'ktczqsl': '1.0000', 'zydm': '110082', 'cbje': '1000.00', 'zrhlje': '0.00', 'dzsxjced': '0.00', 'etfsgcjsl': '0', 'ykbl': '42.02%', 'etfsgdjsl': '0', 'zqlb': 'HH', 'cbj': '100.000', 'zqye': '1', 'etfshcjsl': '0'}, 
        {'xj': '10.070', 'iscyb': '0', 'ksgsl': '100', 'zqmc': '长春经开', 'zrqshsz': '0.00', 'zcxzsl': '0.00', 'fdyk': '-8.02', 'hl': '', 'kyye': '100', 'mmjec': '-1015.02', 'scdm': '1', 'gddm': 'A794459451', 'zrhgsz': '0.00', 'zqdm': '600215', 'kztsl': '100', 'sddjsl': '0.00', 'sz': '1007.00', 'zqsldw': '', 'drmrsl': '0', 'dzptjced': '100.00', 'bfrq': '20211123', 'etfshdjsl': '0', 'jgbz': '01', 'jzcjsl': '0.00', 'drmcsl': '0', 't1hgsz': '0.00', 'ktczqsl': '100.0000', 'zydm': '', 'cbje': '1015.02', 'zrhlje': '0.00', 'dzsxjced': '0.00', 'etfsgcjsl': '0', 'ykbl': '-0.79%', 'etfsgdjsl': '0', 'zqlb': '66', 'cbj': '10.150', 'zqye': '100', 'etfshcjsl': '0'}]}
        """
        url = self.config["balance_url"]
        res = self._post(url)
        try:
            balance_info = json.loads(res)
            if balance_info['success']:
                logger.debug('查询资金股份成功：%s', balance_info)
                return balance_info
            else:
                logger.info('资金股份查询失败：%s, 参数%s', balance_info, self.config)
                return False
        except Exception as e:
            logger.warn("获取资金持仓失败: {}".format(e))
            return False

    def get_balance(self):
        """
        获取账户资金持仓状况
        :return:
        """
        balance_info = self._get_balance_info()
        if not balance_info:
            return False
        else:
            list = {
                "broker": u'招商证券',
                "account": int(balance_info['content']['khh']),
                "asset_balance": float(balance_info['content']['zjlist'][0]['zc']),
                "profit": float(balance_info['content']['zjlist'][0]['yk']),
                "enable_balance": float(balance_info['content']['zjlist'][0]['ky']),
                "market_value": float(balance_info['content']['zjlist'][0]['sz']),
                "money_type": u"人民币",
                "pre_interest": 0.1,
                "holding": balance_info['content']['holding']
            }
            return list

    def get_position(self):
        """
        获取持仓状况
        :return:
        """
        balance_info = self._get_balance_info()
        if not balance_info:
            return False
        else:
            return balance_info['content']['holding']

    def _get_entrust(self):
        """
        获取委托信息
        :return: {'asset_balance': '9310.18', 'profit': '-1056.02', 'enable_balance': '84.98', 'market_value': '9225.20', 'money_type': '人民币', 'pre_interest': 0.1, 
        'holding': [{'xj': '142.020', 'iscyb': '0', 'ksgsl': '1', 'zqmc': 'N宏发转', 'zrqshsz': '1000.00', 'zcxzsl': '0.00', 'fdyk': '420.20', 'hl': '', 'kyye': '1', 'mmjec': '0.00', 'scdm': '1', 'gddm': 'A794459451', 'zrhgsz': '0.00', 'zqdm': '110082', 'kztsl': '1', 'sddjsl': '0.00', 'sz': '1420.20', 'zqsldw': '手', 'drmrsl': '0', 'dzptjced': '1.00', 'bfrq': '20211123', 'etfshdjsl': '0', 'jgbz': '01', 'jzcjsl': '0.00', 'drmcsl': '0', 't1hgsz': '0.00', 'ktczqsl': '1.0000', 'zydm': '110082', 'cbje': '1000.00', 'zrhlje': '0.00', 'dzsxjced': '0.00', 'etfsgcjsl': '0', 'ykbl': '42.02%', 'etfsgdjsl': '0', 'zqlb': 'HH', 'cbj': '100.000', 'zqye': '1', 'etfshcjsl': '0'}, 
        {'xj': '10.070', 'iscyb': '0', 'ksgsl': '100', 'zqmc': '长春经开', 'zrqshsz': '0.00', 'zcxzsl': '0.00', 'fdyk': '-8.02', 'hl': '', 'kyye': '100', 'mmjec': '-1015.02', 'scdm': '1', 'gddm': 'A794459451', 'zrhgsz': '0.00', 'zqdm': '600215', 'kztsl': '100', 'sddjsl': '0.00', 'sz': '1007.00', 'zqsldw': '', 'drmrsl': '0', 'dzptjced': '100.00', 'bfrq': '20211123', 'etfshdjsl': '0', 'jgbz': '01', 'jzcjsl': '0.00', 'drmcsl': '0', 't1hgsz': '0.00', 'ktczqsl': '100.0000', 'zydm': '', 'cbje': '1015.02', 'zrhlje': '0.00', 'dzsxjced': '0.00', 'etfsgcjsl': '0', 'ykbl': '-0.79%', 'etfsgdjsl': '0', 'zqlb': '66', 'cbj': '10.150', 'zqye': '100', 'etfshcjsl': '0'}]}
        """
        url = self.config["entrust_url"]
        res = self._post(url)
        # print(json.loads(html))
        try:
            entrust_info = json.loads(res)['content']
            logger.info('查询委托成功:%s', entrust_info) 
            return entrust_info
        except Exception as e:
            logger.warn("获取委托信息失败:%s".format(e))
            return False
        

    def get_entrust(self):
        """
        获取委托单
        :return:
        """
        return self._get_entrust()

    def _cancel_entrust(self, entrust_no='', shsz=''):
        """
        撤销委托
        :return: {'asset_balance': '9310.18', 'profit': '-1056.02', 'enable_balance': '84.98', 'market_value': '9225.20', 'money_type': '人民币', 'pre_interest': 0.1, 
        'holding': [{'xj': '142.020', 'iscyb': '0', 'ksgsl': '1', 'zqmc': 'N宏发转', 'zrqshsz': '1000.00', 'zcxzsl': '0.00', 'fdyk': '420.20', 'hl': '', 'kyye': '1', 'mmjec': '0.00', 'scdm': '1', 'gddm': 'A794459451', 'zrhgsz': '0.00', 'zqdm': '110082', 'kztsl': '1', 'sddjsl': '0.00', 'sz': '1420.20', 'zqsldw': '手', 'drmrsl': '0', 'dzptjced': '1.00', 'bfrq': '20211123', 'etfshdjsl': '0', 'jgbz': '01', 'jzcjsl': '0.00', 'drmcsl': '0', 't1hgsz': '0.00', 'ktczqsl': '1.0000', 'zydm': '110082', 'cbje': '1000.00', 'zrhlje': '0.00', 'dzsxjced': '0.00', 'etfsgcjsl': '0', 'ykbl': '42.02%', 'etfsgdjsl': '0', 'zqlb': 'HH', 'cbj': '100.000', 'zqye': '1', 'etfshcjsl': '0'}, 
        {'xj': '10.070', 'iscyb': '0', 'ksgsl': '100', 'zqmc': '长春经开', 'zrqshsz': '0.00', 'zcxzsl': '0.00', 'fdyk': '-8.02', 'hl': '', 'kyye': '100', 'mmjec': '-1015.02', 'scdm': '1', 'gddm': 'A794459451', 'zrhgsz': '0.00', 'zqdm': '600215', 'kztsl': '100', 'sddjsl': '0.00', 'sz': '1007.00', 'zqsldw': '', 'drmrsl': '0', 'dzptjced': '100.00', 'bfrq': '20211123', 'etfshdjsl': '0', 'jgbz': '01', 'jzcjsl': '0.00', 'drmcsl': '0', 't1hgsz': '0.00', 'ktczqsl': '100.0000', 'zydm': '', 'cbje': '1015.02', 'zrhlje': '0.00', 'dzsxjced': '0.00', 'etfsgcjsl': '0', 'ykbl': '-0.79%', 'etfsgdjsl': '0', 'zqlb': '66', 'cbj': '10.150', 'zqye': '100', 'etfshcjsl': '0'}]}
        """
        url = self.config["cancel_url"]
        data = {
            "scdm": shsz,
            "hth": entrust_no,
            "jytoken": self.s.cookies.get('cms_token', domain=self._HEADERS['Host'])
        }
        res = self._post(url, data=data)
        # print(json.loads(res))
        try:
            entrust_info = json.loads(res)
            if entrust_info['code'] == "000000":
                logger.info('取消委托成功，原合同号：%s', entrust_no) 
                return True
            else:
                logger.warn('取消委托失败：%s， 提交数据：%s',json.loads(res), data) 
                return False
        except Exception as e:
            logger.warn("获取委托信息失败: {}".format(e))
            return False

    def cancel_entrust(self, stock='', entrust_no='', shsz=''):
        """
        对未成交的委托进行撤单
        :param entrust_no:
        :return:
        """
        if stock != '':
            entrustList = self._get_entrust()
            for entrust in entrustList:
                # print(entrust)
                if stock == entrust['zqdm'] and entrust['cjbz'] == 'W' and int(entrust['wtywdm']) < 3: # W未成交 0已成交 2场内撤单 4场外撤单, wtywdm 01买 02卖
                    entrust_no = entrust['hth']
                    shsz = entrust['scdm']
        if entrust_no != '' and shsz.isspace != '':
            return self._cancel_entrust(entrust_no, shsz)
        else:
            logger.warning("股票%s未找到可以撤销的委托。", stock)
            return False


    def _trade(self, stock_code, price=0, amount=0, volume=0, entrust_bs="buy", entrust_prop='limit'):
        """
        调仓
        :param stock_code:
        :param price:
        :param amount:
        :param volume:
        :param entrust_bs:
        :return: Object or False if failed
        """
        stock_code = ''.join(filter(str.isdigit, stock_code))
        stock = self._search_stock_info(stock_code)
        logger.debug("股票信息：%s", stock)
        if not stock:
            logger.warning(u"获取股票信息失败%s，交易跳过。",stock_code)
            return False
        # balance = self._get_balance_info()['content']['zjlist'][0]
        # logger.debug("资金股份：%s", balance)
        resp = {}
        if int(volume) <= 0:
            volume = int(int(price) * int(amount)) 
        # if float(balance['ky']) < volume and entrust_bs == "buy":
        #     logger.warning(u"可用资金不足，需要%f元,可用%f元", volume, float(balance['ky']))
        #     return False
        if stock["bsl1"] == 0: #买1数量为0
            logger.warning(u"未上市、停牌、涨跌停、退市的股票无法操作。")
            return False
        if volume == 0:
            logger.warning(u"操作金额不能为零")
            return False
        #0指定价格， 2最优5档匹配后剩余转限价    
        entrust_prop = 0 if entrust_prop == 'limit' else 2
        data = {
                "xylist":'',
                "ywqrxx": "",
                "jytoken": self.s.cookies.get('cms_token', domain=self._HEADERS['Host']),
                "scdm": stock['scdm'],
                "gdzh": self.account_config['gdzh_'+stock['scdm']],
                "zqdm": stock_code,
                "wtsl": int(amount),
                "wtjg": price,
                "sjwtbz": entrust_prop, 
                "tjrdm": ""
            }
        try:
            resp = json.loads(self._post(self.config[entrust_bs+"_url"], data=data))
            # logger.info('交易请求响应：%s', resp)
            if not resp['success']:
                logger.warn('交易失败：%s 交易数据：%s',resp['message'],data)
                return False
            else:
                resp = resp['content']['applyResult'][0]
            if resp['hth'] != "":
                logger.info("调仓%s %s %s股成功", entrust_bs, stock["zqjc"], amount)
                return {
                        "entrust_no": resp["hth"],
                        "init_date": resp['sjjyrq'],
                        "entrust_price": price,
                        "entrust_amount": amount,
                        "entrust_volume": volume,
                        "stock_code": stock_code,
                        "entrust_bs": entrust_bs,
                }
            else:
                logger.error("获取委托合同号失败：%s, 请求信息: %s - %s", resp, self.config[entrust_bs+"_url"], data)
                return False
        # pylint: disable=broad-except
        except Exception as e:
            logger.warning("调仓错误: %s，返回信息：%s ", e, resp)
            return False

    def buy(self, security, price=0, amount=0, volume=0, entrust_prop='limit'):
        """买入股票
        :param security: 股票代码
        :param price: 买入价格
        :param amount: 买入股数
        :param volume: 买入总金额 由 volume / price 取整， 若指定 price 则此参数无效
        """
        return self._trade(security, price, amount, volume, "buy", entrust_prop)

    def sell(self, security, price=0, amount=0, volume=0, entrust_prop='limit'):
        """卖出股票
        :param security: 股票代码
        :param price: 卖出价格
        :param amount: 卖出股数
        :param volume: 卖出总金额 由 volume / price 取整， 若指定 price 则此参数无效
        """
        return self._trade(security, price, amount, volume, "sell", entrust_prop)
